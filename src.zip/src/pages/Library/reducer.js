const reducer = (
  state = {
    shiftMultipleMode: false
  },
  action
) => {
  switch (action.type) {
    default:
      return state
  }
}

export default reducer
