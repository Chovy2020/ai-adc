const reducer = (
  state = {
    shiftMultipleMode: false,
    activeMenu: 'toolbox',
    toolBoxLoading: false
  },
  action
) => {
  switch (action.type) {
    default:
      return state
  }
}

export default reducer
